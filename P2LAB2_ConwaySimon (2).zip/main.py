current_price = int(input())
last_month_price = int(input())
Estimate_Mortgage = current_price*0.051/12

print("This house is ${}. The change is ${} since last month.".format(current_price,current_price-last_month_price))
print("The estimated monthly mortgage is ${:.2f}.".format(Estimate_Mortgage))