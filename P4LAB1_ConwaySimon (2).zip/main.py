text = input('')

text = text.replace(" ", "")

text = text.replace(".", "")

text = text.replace("!", "")

text = text.replace(",", "")

print(len(text))
