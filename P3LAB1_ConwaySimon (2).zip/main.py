r=int(input())

g=int(input())

b=int(input())

m=min([r,g,b])

print(str(r-m)+" "+str(g-m)+" "+str(b-m))